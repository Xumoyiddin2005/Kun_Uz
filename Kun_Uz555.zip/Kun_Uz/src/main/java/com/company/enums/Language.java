package com.company.enums;
// PROJECT NAME lesson_14_kun_uz
// TIME 18:30
// MONTH 06
// DAY 13


public enum Language {
    uz,ru,en

}
