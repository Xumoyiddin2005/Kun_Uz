package com.company.enums;

public enum ProfileRole {

    ADMIN, PUBLISHER, MODERATOR, USER

}
