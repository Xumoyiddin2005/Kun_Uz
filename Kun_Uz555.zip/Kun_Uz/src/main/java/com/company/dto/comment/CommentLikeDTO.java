package com.company.dto.comment;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CommentLikeDTO {
    private Integer commentId;
}
