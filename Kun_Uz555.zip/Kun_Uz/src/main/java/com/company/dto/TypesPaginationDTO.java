package com.company.dto;
// PROJECT NAME lesson_14_kun_uz
// TIME 19:18
// MONTH 06
// DAY 13

import com.company.dto.article.TypesDTO;

import java.util.List;

public class TypesPaginationDTO {

    private long totalAmount;
    private List<TypesDTO> list;
}
