package com.company.controller;

import org.springframework.web.bind.annotation.*;

@RequestMapping("/save_articles")
@RestController
public class SavedArticleController {

}
