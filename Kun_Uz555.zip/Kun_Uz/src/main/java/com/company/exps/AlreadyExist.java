package com.company.exps;

public class AlreadyExist extends RuntimeException{

    public AlreadyExist(String message) {
        super(message);
    }
}
