package com.company.exps;

public class AlreadyExistNameAndSurName extends RuntimeException {
    public AlreadyExistNameAndSurName(String massage) {
        super(massage);
    }
}
